 #include "HashTableShift.h"
 
 //ŕemoves an element from the table according to strategy 2, also updates the number of elements
 void HashTableShift::removeElement(int element)
 {
        //TODO d)
}
