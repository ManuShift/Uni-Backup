#include "HashTableSkip.h"

//ŕemoves an element from the table according to strategy 2, also updates the number of elements as well as the garbageCount.
//calls the clear() method if the garbageLimit is reached
void HashTableSkip::removeElement(int element)
{
	//TODO b)
}

void HashTableSkip::clear()
{
	//TODO c)
}
