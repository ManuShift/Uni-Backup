int werwoelfe(int t);
int vampire(int t);
int knoblauchbauern(int t);