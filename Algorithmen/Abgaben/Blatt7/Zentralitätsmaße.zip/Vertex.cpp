#include "Vertex.h"

string Vertex::getLabel()
{
	return label;
}

Vertex::Vertex (string _label)
{
	label = _label;
}
