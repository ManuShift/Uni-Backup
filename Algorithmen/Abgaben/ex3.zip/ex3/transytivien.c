#include "transytivien.h"

int knoblauchbauern(int t)
{
    //TODO: Funktion vervollständigen

int vampire(int t)
{
    //TODO: Funktion vervollständigen
}

int werwoelfe(int t)
{
    //TODO: Funktion vervollständigen
}
